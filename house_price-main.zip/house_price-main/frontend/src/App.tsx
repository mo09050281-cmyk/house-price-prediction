import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

interface PredictionResponse {
  predicted_price: number;
  currency: string;
}

function App() {
  const [locations, setLocations] = useState<string[]>([]);
  const [formData, setFormData] = useState({
    carpet_area_sqft: 1000,
    floor_num: 2,
    bathroom: 2,
    balcony: 1,
    location_grouped: '',
    Furnishing: 'Unfurnished',
    Transaction: 'Resale',
    Ownership: 'Freehold',
    facing: 'North'
  });

  const [result, setResult] = useState<PredictionResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/locations')
      .then(res => {
        if (res.data.locations && res.data.locations.length > 0) {
          setLocations(res.data.locations);
          setFormData(prev => ({ ...prev, location_grouped: res.data.locations[0] }));
        }
      })
      .catch(err => console.error("Error fetching locations:", err));
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: ['carpet_area_sqft', 'floor_num', 'bathroom', 'balcony'].includes(name)
        ? parseFloat(value) || 0
        : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post<PredictionResponse>('http://127.0.0.1:8000/predict', formData);
      setResult(response.data);
    } catch (error) {
      console.error("Error making prediction:", error);
      alert("An error occurred while connecting to the system!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '40px auto', padding: '20px', fontFamily: 'Arial, sans-serif', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', borderRadius: '10px' }}>
      <h2 style={{ textAlign: 'center', color: '#2c3e50' }}>🏡 House Price Prediction System</h2>
      
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
        <div>
          <label>Carpet Area (sqft):</label>
          <input type="number" name="carpet_area_sqft" value={formData.carpet_area_sqft} onChange={handleChange} required style={inputStyle} />
        </div>

        <div>
          <label>Floor Number:</label>
          <input type="number" name="floor_num" value={formData.floor_num} onChange={handleChange} required style={inputStyle} />
        </div>

        <div>
          <label>Bathrooms:</label>
          <input type="number" name="bathroom" value={formData.bathroom} onChange={handleChange} required style={inputStyle} />
        </div>

        <div>
          <label>Balconies:</label>
          <input type="number" name="balcony" value={formData.balcony} onChange={handleChange} required style={inputStyle} />
        </div>

        <div>
          <label>Location:</label>
          <select name="location_grouped" value={formData.location_grouped} onChange={handleChange} style={inputStyle}>
            {locations.map((loc, idx) => (
              <option key={idx} value={loc}>{loc}</option>
            ))}
          </select>
        </div>

        <div>
          <label>Furnishing Status:</label>
          <select name="Furnishing" value={formData.Furnishing} onChange={handleChange} style={inputStyle}>
            <option value="Unfurnished">Unfurnished</option>
            <option value="Semi-Furnished">Semi-Furnished</option>
            <option value="Furnished">Furnished</option>
          </select>
        </div>

        <button type="submit" disabled={loading} style={buttonStyle}>
          {loading ? 'Calculating...' : 'Predict Price 💰'}
        </button>
      </form>

      {result && (
        <div style={{ marginTop: '25px', padding: '15px', backgroundColor: '#e8f8f5', borderRadius: '8px', textAlign: 'center' }}>
          <h3 style={{ color: '#27ae60', margin: 0 }}>Predicted Price:</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#2c3e50', margin: '10px 0 0 0' }}>
            {result.predicted_price.toLocaleString()} {result.currency}
          </p>
        </div>
      )}
    </div>
  );
}

const inputStyle = {
  width: '100%',
  padding: '8px',
  marginTop: '5px',
  borderRadius: '5px',
  border: '1px solid #ccc',
  boxSizing: 'border-box' as const
};

const buttonStyle = {
  backgroundColor: '#3498db',
  color: '#fff',
  padding: '12px',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
  fontSize: '16px',
  fontWeight: 'bold' as const
};

export default App;