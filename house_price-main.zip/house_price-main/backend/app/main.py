from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import joblib
import pandas as pd
import numpy as np
import os
import json
from app.schemas.prediction import PredictionRequest, PredictionResponse

app = FastAPI(title="House Price Prediction API")

# تفعيل الـ CORS لتوفير إمكانية اتصال الـ Frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# تحديد المسارات
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "models", "house_price.pkl")
LOCATIONS_PATH = os.path.join(BASE_DIR, "models", "locations.json")

model = None
locations = []

@app.on_event("startup")
def load_model():
    global model, locations
    if os.path.exists(MODEL_PATH):
        model = joblib.load(MODEL_PATH)
    if os.path.exists(LOCATIONS_PATH):
        with open(LOCATIONS_PATH, "r") as f:
            locations = json.load(f)

@app.get("/health")
def health_check():
    return {"status": "ok", "model_loaded": model is not None}

@app.get("/locations")
def get_locations():
    return {"locations": locations}

@app.post("/predict", response_model=PredictionResponse)
def predict_price(request: PredictionRequest):
    if model is None:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    input_data = pd.DataFrame([request.model_dump()])
    log_pred = model.predict(input_data)[0]
    predicted_price = float(np.expm1(log_pred))
    
    return PredictionResponse(predicted_price=round(predicted_price, 2))