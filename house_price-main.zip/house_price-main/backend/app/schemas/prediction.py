from pydantic import BaseModel, Field

class PredictionRequest(BaseModel):
    carpet_area_sqft: float = Field(..., gt=0, description="Area in sqft")
    floor_num: float = Field(..., ge=0, description="Floor number")
    bathroom: float = Field(..., ge=0, description="Number of bathrooms")
    balcony: float = Field(..., ge=0, description="Number of balconies")
    location_grouped: str = Field(..., description="Location name")
    Furnishing: str = Field(default="Unfurnished")
    Transaction: str = Field(default="Resale")
    Ownership: str = Field(default="Freehold")
    facing: str = Field(default="North")

class PredictionResponse(BaseModel):
    predicted_price: float
    currency: str = "INR"