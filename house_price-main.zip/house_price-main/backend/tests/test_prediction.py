from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

def test_predict_success():
    payload = {
        "carpet_area_sqft": 1000,
        "floor_num": 2,
        "bathroom": 2,
        "balcony": 1,
        "location_grouped": "agra",
        "Furnishing": "Unfurnished",
        "Transaction": "Resale",
        "Ownership": "Freehold",
        "facing": "North"
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    assert "predicted_price" in response.json()

def test_predict_invalid_input():
    payload = {
        "carpet_area_sqft": "invalid_number"
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 422